SHADOW STRIKE: FRONTLINE — Android build project

Телефонный способ:
1. Создай GitHub-репозиторий.
2. Загрузи в него все файлы этой папки.
3. Открой вкладку Actions.
4. Запусти "Build Shadow Strike APK".
5. После завершения открой результат workflow и скачай artifact shadow-strike-apk.
6. Внутри будет app-debug.apk.

Проект специально настроен так, чтобы исходный HTML5-файл лежал в www/index.html.
