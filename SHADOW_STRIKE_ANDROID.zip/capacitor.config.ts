import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.solus.shadowstrike',
  appName: 'SHADOW STRIKE',
  webDir: 'www'
};

export default config;
